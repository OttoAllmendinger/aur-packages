cd /opt/CrayonPhysicsDeluxe
exec ./launcher "$@"
